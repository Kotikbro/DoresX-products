#include "Android_draw/draw.h"
#include "fonts/menu/pixeloperator.h"
#include "fonts/menu/comfortaa.h"
#include "fonts/menu/comicsans.h"
#include "fonts/menu/minecraft.h"
#include "fonts/esp/esp.h"
#include <GLES3/gl3.h>

EGLDisplay display = EGL_NO_DISPLAY;
EGLConfig config;
EGLSurface surface = EGL_NO_SURFACE;
EGLContext context = EGL_NO_CONTEXT;

ANativeWindow *native_window;

// ── Активные указатели (всегда указывают на текущий набор из g_font_table) ───
ImFont* fontBold   = nullptr;
ImFont* fontMedium = nullptr;
ImFont* fontDesc   = nullptr;
ImFont* espFont    = nullptr;

// ── Таблица [font_idx 0..3][size: 0=Bold 1=Medium 2=Desc] ───────────────────
ImFont* g_font_table[4][3] = {
    { nullptr, nullptr, nullptr },  // 0: PixelOperator
    { nullptr, nullptr, nullptr },  // 1: Comfortaa
    { nullptr, nullptr, nullptr },  // 2: ComicSans
    { nullptr, nullptr, nullptr },  // 3: Minecraft
};

int native_window_screen_x = 0;
int native_window_screen_y = 0;
android::ANativeWindowCreator::DisplayInfo displayInfo{0};
uint32_t orientation = 0;
bool g_Initialized = false;
int   g_font_idx   = 0;
float g_font_scale = 1.0f;
ImGuiWindow *g_window = nullptr;

// ── Размеры шрифтов для каждого уровня ──────────────────────────────────────
// Bold/Medium/Desc — одинаковы для всех шрифтов чтобы layout не прыгал
static const float FONT_SIZE_BOLD   = 32.f;
static const float FONT_SIZE_MEDIUM = 28.f;
static const float FONT_SIZE_DESC   = 22.f;

bool initGUI_draw(uint32_t _screen_x, uint32_t _screen_y, bool log) {
    orientation = displayInfo.orientation;
    if (!init_egl(_screen_x, _screen_y, log)) return false;
    if (!ImGui_init()) return false;
    return true;
}

bool init_egl(uint32_t _screen_x, uint32_t _screen_y, bool log) {
    ::native_window = android::ANativeWindowCreator::Create("Overlay", _screen_x, _screen_y, false);

    ANativeWindow_acquire(native_window);
    display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) return false;
    if (eglInitialize(display, 0, 0) != EGL_TRUE) return false;

    EGLint num_config = 0;
    const EGLint attribList[] = {
        EGL_SURFACE_TYPE,     EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE,  EGL_OPENGL_ES2_BIT,
        EGL_BLUE_SIZE,  5,
        EGL_GREEN_SIZE, 6,
        EGL_RED_SIZE,   5,
        EGL_BUFFER_SIZE,  32,
        EGL_DEPTH_SIZE,   16,
        EGL_STENCIL_SIZE,  8,
        EGL_NONE
    };
    const EGLint attrib_list[] = {
        EGL_CONTEXT_CLIENT_VERSION, 3,
        EGL_NONE
    };

    if (eglChooseConfig(display, attribList, &config, 1, &num_config) != EGL_TRUE) return false;

    EGLint egl_format;
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &egl_format);
    ANativeWindow_setBuffersGeometry(native_window, 0, 0, egl_format);
    context = eglCreateContext(display, config, EGL_NO_CONTEXT, attrib_list);
    if (context == EGL_NO_CONTEXT) return false;

    surface = eglCreateWindowSurface(display, config, native_window, nullptr);
    if (surface == EGL_NO_SURFACE) return false;
    if (!eglMakeCurrent(display, surface, surface, context)) return false;

    return true;
}

void screen_config() {
    displayInfo = android::ANativeWindowCreator::GetDisplayInfo();
}

// ── Вспомогательная: загрузить шрифт с Cyrillic range ───────────────────────
static ImFont* load_font(ImFontAtlas* atlas,
                         const unsigned char* data, int data_size,
                         float size_px)
{
    ImFontConfig fc;
    fc.FontDataOwnedByAtlas = false;   // ВАЖНО: данные в .h — не копируем, не освобождаем
    return atlas->AddFontFromMemoryTTF(
        (void*)data, data_size, size_px, &fc,
        atlas->GetGlyphRangesCyrillic());
}

bool ImGui_init() {
    if (g_Initialized) return true;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();
    ImGui_ImplAndroid_Init(native_window);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = NULL;

    ImFontAtlas* atlas = io.Fonts;

    // ── 0: PixelOperator ─────────────────────────────────────────────────────
    g_font_table[0][0] = load_font(atlas, pixeloperator, sizeof(pixeloperator), FONT_SIZE_BOLD);
    g_font_table[0][1] = load_font(atlas, pixeloperator, sizeof(pixeloperator), FONT_SIZE_MEDIUM);
    g_font_table[0][2] = load_font(atlas, pixeloperator, sizeof(pixeloperator), FONT_SIZE_DESC);

    // ── 1: Comfortaa ─────────────────────────────────────────────────────────
    g_font_table[1][0] = load_font(atlas, comfortaa, sizeof(comfortaa), FONT_SIZE_BOLD);
    g_font_table[1][1] = load_font(atlas, comfortaa, sizeof(comfortaa), FONT_SIZE_MEDIUM);
    g_font_table[1][2] = load_font(atlas, comfortaa, sizeof(comfortaa), FONT_SIZE_DESC);

    // ── 2: ComicSans ─────────────────────────────────────────────────────────
    g_font_table[2][0] = load_font(atlas, comicsans, sizeof(comicsans), FONT_SIZE_BOLD);
    g_font_table[2][1] = load_font(atlas, comicsans, sizeof(comicsans), FONT_SIZE_MEDIUM);
    g_font_table[2][2] = load_font(atlas, comicsans, sizeof(comicsans), FONT_SIZE_DESC);

    // ── 3: Minecraft ─────────────────────────────────────────────────────────
    g_font_table[3][0] = load_font(atlas, minecraft, sizeof(minecraft), FONT_SIZE_BOLD);
    g_font_table[3][1] = load_font(atlas, minecraft, sizeof(minecraft), FONT_SIZE_MEDIUM);
    g_font_table[3][2] = load_font(atlas, minecraft, sizeof(minecraft), FONT_SIZE_DESC);

    // ── ESP — отдельный шрифт, никогда не меняется ───────────────────────────
    espFont = load_font(atlas, esp, sizeof(esp), 18.f);

    // ── Дефолтный набор — PixelOperator ──────────────────────────────────────
    fontBold   = g_font_table[1][0];
    fontMedium = g_font_table[1][1];
    fontDesc   = g_font_table[1][2];
    io.FontDefault = fontMedium;

    ImGui::GetStyle().ScaleAllSizes(3.0f);

    ::g_Initialized = true;
    return true;
}

void drawBegin() {
    screen_config();
    if (::orientation != displayInfo.orientation) {
        ::orientation = displayInfo.orientation;
        touch::update(displayInfo.width, displayInfo.height, displayInfo.orientation);
        if (g_window) {
            g_window->Pos.x = 100;
            g_window->Pos.y = 125;
        }
    }

    // ── Смена шрифтового набора ДО NewFrame ──────────────────────────────────
    // g_font_idx/g_font_scale пишет menu.cpp в render() перед этим вызовом.
    // Меняем ВСЕ три указателя сразу — Bold/Medium/Desc.
    // Scale сбрасываем у всех шрифтов в таблице, применяем только к активному набору.
    if (g_Initialized) {
        int idx = (g_font_idx >= 0 && g_font_idx <= 3) ? g_font_idx : 0;

        // Проверяем что шрифты загружены
        if (g_font_table[idx][0] && g_font_table[idx][0]->IsLoaded() &&
            g_font_table[idx][1] && g_font_table[idx][1]->IsLoaded() &&
            g_font_table[idx][2] && g_font_table[idx][2]->IsLoaded())
        {
            // Сброс Scale у ВСЕХ шрифтов в таблице
            for (int fi = 0; fi < 4; fi++) {
                for (int si = 0; si < 3; si++) {
                    if (g_font_table[fi][si]) {
                        g_font_table[fi][si]->Scale = 1.0f;
                    }
                }
            }

            // Применяем Scale только к активному набору
            float scale = (g_font_scale > 0.1f) ? g_font_scale : 1.0f;
            g_font_table[idx][0]->Scale = scale;
            g_font_table[idx][1]->Scale = scale;
            g_font_table[idx][2]->Scale = scale;

            // Обновляем глобальные указатели
            fontBold   = g_font_table[idx][0];
            fontMedium = g_font_table[idx][1];
            fontDesc   = g_font_table[idx][2];

            ImGui::GetIO().FontDefault = fontMedium;
        }
        // espFont — Scale никогда не трогаем
    }
    // ─────────────────────────────────────────────────────────────────────────

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(native_window_screen_x, native_window_screen_y);
    ImGui::NewFrame();
}

void drawEnd() {
    ImGui::Render();
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(display, surface);
}

void shutdown() {
    if (!g_Initialized) return;

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();

    if (display != EGL_NO_DISPLAY) {
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context != EGL_NO_CONTEXT) eglDestroyContext(display, context);
        if (surface != EGL_NO_SURFACE) eglDestroySurface(display, surface);
        eglTerminate(display);
    }
    display = EGL_NO_DISPLAY;
    context = EGL_NO_CONTEXT;
    surface = EGL_NO_SURFACE;

    ANativeWindow_release(native_window);
    android::ANativeWindowCreator::Destroy(native_window);
    ::g_Initialized = false;
}
