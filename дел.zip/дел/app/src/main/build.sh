/data/data/com.aide.plus/no_backup/ndksupport-1710240003/android-ndk-aide/ndk-build
