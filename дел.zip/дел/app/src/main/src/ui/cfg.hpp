#pragma once
#include "imgui.h"
#include <math.h>

// ── RGB helpers (из rage/colors.h) ───────────────────────────
namespace cfg {

namespace rgb {
    inline float  speed      = 1.2f;

    inline ImVec4 color4(float offset = 0.f) {
        float t = (float)ImGui::GetTime() * speed + offset;
        return ImVec4(
            sinf(t)          * 0.5f + 0.5f,
            sinf(t + 2.094f) * 0.5f + 0.5f,
            sinf(t + 4.189f) * 0.5f + 0.5f,
            1.0f);
    }

    inline ImU32 color32(int alpha = 255, float offset = 0.f) {
        ImVec4 c = color4(offset);
        return IM_COL32((int)(c.x*255),(int)(c.y*255),(int)(c.z*255), alpha);
    }
}

namespace esp {
    // ── Toggles ──────────────────────────────────────────────
    inline bool box             = false;
    inline bool name            = false;
    inline bool health          = false;
    inline bool health_text     = false;
    inline bool distance        = false;
    inline bool line            = false;
    inline bool   head_circle     = false;
    inline ImVec4 head_circle_col = ImVec4(1.f, 0.f, 0.f, 1.f);
    inline bool   head_circle_rgb = false;
    inline bool   skeleton        = false;
    inline ImVec4 skeleton_col    = ImVec4(1.f, 0.f, 0.f, 1.f);
    inline bool   skeleton_rgb    = false;
    inline bool box_fill        = false;

    // ── Box ──────────────────────────────────────────────────
    inline int   box_type       = 0;        // 0=full 1=corner
    inline float box_rounding   = 0.f;
    inline ImVec4 box_col       = ImVec4(1.f, 0.f, 0.f, 1.f);
    inline bool   box_rgb       = false;

    // ── Fill ─────────────────────────────────────────────────
    inline float  fill_alpha    = 0.15f;
    inline int    fill_type     = 0;        // 0=Normal 1=Gradient
    inline ImVec4 fill_col      = ImVec4(1.f, 0.f, 0.f, 1.f);
    inline bool   fill_rgb      = false;
    inline ImVec4 fill_col_top  = ImVec4(1.f, 0.f, 0.f, 1.f);
    inline ImVec4 fill_col_bot  = ImVec4(0.55f, 0.f, 0.f, 1.f);

    // ── Name ─────────────────────────────────────────────────
    inline ImVec4 name_col      = ImVec4(1.f, 0.f, 0.f, 1.f);
    inline bool   name_rgb      = false;

    // ── HP bar ───────────────────────────────────────────────
    inline ImVec4 health_col    = ImVec4(1.f, 0.f, 0.f, 1.f);
    inline bool   health_rgb    = false;

    // ── HP text ──────────────────────────────────────────────
    inline ImVec4 hptext_col    = ImVec4(1.f, 0.f, 0.f, 1.f);
    inline bool   hptext_rgb    = false;

    // ── Distance ─────────────────────────────────────────────
    inline ImVec4 distance_col  = ImVec4(1.f, 0.f, 0.f, 1.f);
    inline bool   distance_rgb  = false;

    // ── Line ─────────────────────────────────────────────────
    inline ImVec4 line_col      = ImVec4(1.f, 0.f, 0.f, 1.f);
    inline bool   line_rgb      = false;

    // ── ESP Preview Window ────────────────────────────────────
    inline bool   preview_visible = false;
}

namespace crosshair {
    inline bool  enabled        = false;
    inline int   type           = 1;
    inline float size           = 8.0f;
    inline float thick          = 1.8f;
    inline float gap            = 2.0f;
    inline bool  outline        = true;
    inline bool  rgb            = false;
    inline ImVec4 color         = ImVec4(1.f, 1.f, 1.f, 1.f);
    inline bool  spin           = false;
    inline float spin_speed     = 1.5f;
}

}

