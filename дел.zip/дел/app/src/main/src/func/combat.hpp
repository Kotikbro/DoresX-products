#pragma once

#include <stdint.h>

// ─────────────────────────────────────────────────────────────────────────────
//  CFG — только аим, легит онли
// ─────────────────────────────────────────────────────────────────────────────
namespace cfg {
namespace combat {

    // ── Aimbot ───────────────────────────────────────────────────────────────
    inline bool  aimbot           = false;
    inline bool  aimbot_visible   = false;
    inline float aimbot_fov       = 70.0f;
    inline float aimbot_smooth    = 0.25f;
    inline bool  aimbot_fov_draw  = true;
    inline bool  aimbot_lock_line = true;
    inline bool  aimbot_lock_dot  = true;
    inline float aimbot_max_dist  = 250.0f;

} // namespace combat
} // namespace cfg

// ─────────────────────────────────────────────────────────────────────────────
//  PUBLIC API
// ─────────────────────────────────────────────────────────────────────────────
namespace combat {
    void tick(uint64_t local_player);
    void aimbot_tick(uint64_t local_player);
    void aimbot_draw_fov(void* draw_list, float screen_w, float screen_h);
}
