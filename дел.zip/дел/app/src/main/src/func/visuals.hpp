#pragma once

#include "imgui.h"
#include "imgui_internal.h"   // ImRect
#include "../game/game.hpp"   // matrix

namespace visuals {
    void draw();

    // ── Примитивы бокса ──────────────────────────────────────
    void dbox_full   (ImDrawList* dl, const ImRect& r, float alpha);
    void dbox_corner (ImDrawList* dl, const ImRect& r, float alpha);
    void dbox_fill   (ImDrawList* dl, const ImRect& r);

    // ── ESP элементы ─────────────────────────────────────────
    void dnick       (ImDrawList* dl, const ImRect& r, const char* nick);
    void dhp_bar     (ImDrawList* dl, const ImRect& r, int hp);
    void dhp_text    (ImDrawList* dl, const ImRect& r, int hp);
    void ddist       (ImDrawList* dl, const ImRect& r, float dist);
    void dline       (ImDrawList* dl, const ImRect& r);
    void dhead_circle(ImDrawList* dl, const ImRect& r);
    void dskeleton   (ImDrawList* dl, const ImRect& r);

    // ── Прицел ───────────────────────────────────────────────
    void dcrosshair  (ImDrawList* dl);

    // ── Утилиты ──────────────────────────────────────────────
    void draw_text_outlined(ImDrawList* dl, ImFont* font, float size,
                            const ImVec2& pos, ImU32 color, const char* text);
}

