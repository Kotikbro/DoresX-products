#include "visuals.hpp"
#include "../game/game.hpp"
#include "../game/offsets.hpp"
#include "../game/math.hpp"
#include "../game/player.hpp"
#include "../ui/theme/theme.hpp"
#include "../ui/cfg.hpp"
#include "../protect/oxorany.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <algorithm>

extern ImFont* espFont;

// ─────────────────────────────────────────────────────────────────────────────
//  INTERNAL HELPERS
// ─────────────────────────────────────────────────────────────────────────────

// helper: ImVec4 + RGB флаг → ImU32 с полной альфой
static inline ImU32 esp_col32(const ImVec4& c, bool rgb, float phase = 0.f) {
    if (rgb) return cfg::rgb::color32(255, phase);
    return IM_COL32((int)(c.x*255),(int)(c.y*255),(int)(c.z*255),(int)(c.w*255));
}

// helper: ImVec4 + RGB флаг → ImU32 с заданной альфой
static inline ImU32 esp_col32a(const ImVec4& c, bool rgb, int alpha, float phase = 0.f) {
    if (rgb) return cfg::rgb::color32(alpha, phase);
    return IM_COL32((int)(c.x*255),(int)(c.y*255),(int)(c.z*255), alpha);
}

// helper: вращение точки вокруг центра на угол a (радианы)
static inline ImVec2 rotate_around(float cx, float cy,
                                   float dx, float dy, float a)
{
    float c = cosf(a), s = sinf(a);
    return ImVec2(cx + dx * c - dy * s,
                  cy + dx * s + dy * c);
}

// ─────────────────────────────────────────────────────────────────────────────
//  DrawGradientRounded
//  Градиентный fill с округлёнными углами через ручную запись вершин.
//  C++14: никаких лямбд, никаких auto-параметров.
// ─────────────────────────────────────────────────────────────────────────────
static void draw_gradient_rounded(ImDrawList* dl,
                                  ImVec2 pMin, ImVec2 pMax,
                                  ImU32 col_top, ImU32 col_bot,
                                  float rnd)
{
    if (rnd < 0.5f) {
        dl->AddRectFilledMultiColor(pMin, pMax, col_top, col_top, col_bot, col_bot);
        return;
    }

    float w = pMax.x - pMin.x;
    float h = pMax.y - pMin.y;
    if (w < 1.f || h < 1.f) return;

    float half_min = (w < h ? w : h) * 0.5f;
    if (rnd > half_min) rnd = half_min;

    // Распаковка IM_COL32 (LE: R=bits0-7, G=8-15, B=16-23, A=24-31)
    float tr = (float)((col_top >>  0) & 0xFF);
    float tg = (float)((col_top >>  8) & 0xFF);
    float tb = (float)((col_top >> 16) & 0xFF);
    float ta = (float)((col_top >> 24) & 0xFF);
    float br = (float)((col_bot >>  0) & 0xFF);
    float bg = (float)((col_bot >>  8) & 0xFF);
    float bb = (float)((col_bot >> 16) & 0xFF);
    float ba = (float)((col_bot >> 24) & 0xFF);

    // Lerp по нормализованной Y
    #define LGCOL(yn) IM_COL32( \
        (int)(tr + (br - tr) * (yn)), \
        (int)(tg + (bg - tg) * (yn)), \
        (int)(tb + (bb - tb) * (yn)), \
        (int)(ta + (ba - ta) * (yn))  \
    )

    const int ARC_SEGS = 8;
    const int N_PERIM  = 4 * ARC_SEGS;
    const int N_VTX    = N_PERIM + 1;
    const int N_IDX    = N_PERIM * 3;

    dl->PrimReserve(N_IDX, N_VTX);

    ImVec2      uv        = dl->_Data->TexUvWhitePixel;
    ImDrawVert* vw        = dl->_VtxWritePtr;
    ImDrawIdx*  iw        = dl->_IdxWritePtr;
    ImDrawIdx   base      = (ImDrawIdx)dl->_VtxCurrentIdx;

    // вертекс 0 — центр
    float cxm = (pMin.x + pMax.x) * 0.5f;
    float cym = (pMin.y + pMax.y) * 0.5f;
    vw[0].pos = ImVec2(cxm, cym);
    vw[0].uv  = uv;
    vw[0].col = LGCOL(0.5f);

    float cx0 = pMin.x + rnd;
    float cx1 = pMax.x - rnd;
    float cy0 = pMin.y + rnd;
    float cy1 = pMax.y - rnd;

    int vi = 1;

    // TL: 180° → 270°
    for (int i = 0; i < ARC_SEGS; i++) {
        float a  = IM_PI * 1.0f + (IM_PI * 0.5f) * ((float)i / (float)ARC_SEGS);
        float vx = cx0 + cosf(a) * rnd;
        float vy = cy0 + sinf(a) * rnd;
        vw[vi].pos = ImVec2(vx, vy);
        vw[vi].uv  = uv;
        vw[vi].col = LGCOL((vy - pMin.y) / h);
        vi++;
    }
    // TR: 270° → 360°
    for (int i = 0; i < ARC_SEGS; i++) {
        float a  = IM_PI * 1.5f + (IM_PI * 0.5f) * ((float)i / (float)ARC_SEGS);
        float vx = cx1 + cosf(a) * rnd;
        float vy = cy0 + sinf(a) * rnd;
        vw[vi].pos = ImVec2(vx, vy);
        vw[vi].uv  = uv;
        vw[vi].col = LGCOL((vy - pMin.y) / h);
        vi++;
    }
    // BR: 0° → 90°
    for (int i = 0; i < ARC_SEGS; i++) {
        float a  = 0.f + (IM_PI * 0.5f) * ((float)i / (float)ARC_SEGS);
        float vx = cx1 + cosf(a) * rnd;
        float vy = cy1 + sinf(a) * rnd;
        vw[vi].pos = ImVec2(vx, vy);
        vw[vi].uv  = uv;
        vw[vi].col = LGCOL((vy - pMin.y) / h);
        vi++;
    }
    // BL: 90° → 180°
    for (int i = 0; i < ARC_SEGS; i++) {
        float a  = IM_PI * 0.5f + (IM_PI * 0.5f) * ((float)i / (float)ARC_SEGS);
        float vx = cx0 + cosf(a) * rnd;
        float vy = cy1 + sinf(a) * rnd;
        vw[vi].pos = ImVec2(vx, vy);
        vw[vi].uv  = uv;
        vw[vi].col = LGCOL((vy - pMin.y) / h);
        vi++;
    }

    // Fan triangulation
    for (int i = 0; i < N_PERIM; i++) {
        iw[i * 3 + 0] = base;
        iw[i * 3 + 1] = (ImDrawIdx)(base + 1 + i);
        iw[i * 3 + 2] = (ImDrawIdx)(base + 1 + (i + 1) % N_PERIM);
    }

    dl->_VtxWritePtr   += N_VTX;
    dl->_IdxWritePtr   += N_IDX;
    dl->_VtxCurrentIdx += (unsigned int)N_VTX;

    #undef LGCOL
}

// ─────────────────────────────────────────────────────────────────────────────
//  SKELETON HELPER
// ─────────────────────────────────────────────────────────────────────────────

static void skel_line(ImDrawList* dl, ImU32 col,
                      const ImVec2& a, const ImVec2& b)
{
    dl->AddLine(a, b, IM_COL32(0,0,0,200), 2.8f);
    dl->AddLine(a, b, col,                  1.6f);
}

// ─────────────────────────────────────────────────────────────────────────────
//  PUBLIC API
// ─────────────────────────────────────────────────────────────────────────────

void visuals::draw_text_outlined(ImDrawList* dl, ImFont* font, float size,
                                 const ImVec2& pos, ImU32 color, const char* text)
{
    if (!font || !dl || !text) return;
    int a  = (color >> IM_COL32_A_SHIFT) & 0xFF;
    int s1 = (int)(a * 0.4f);
    int s2 = (int)(a * 0.7f);
    dl->AddText(font, size, ImVec2(pos.x + 2.f, pos.y + 2.f), IM_COL32(0,0,0,s1), text);
    dl->AddText(font, size, ImVec2(pos.x + 1.f, pos.y + 1.f), IM_COL32(0,0,0,s2), text);
    dl->AddText(font, size, pos,                               color,               text);
}

// ── Full box (outline + тень) ─────────────────────────────────────────────────
void visuals::dbox_full(ImDrawList* dl, const ImRect& r, float alpha) {
    ImU32 col   = esp_col32a(cfg::esp::box_col, cfg::esp::box_rgb,
                             (int)(cfg::esp::box_col.w * alpha * 255.f), 0.f);
    ImU32 black = IM_COL32(0, 0, 0, (int)(255 * alpha));
    float rnd   = cfg::esp::box_rounding;
    dl->AddRect(r.Min, r.Max, black, rnd, 0, 2.8f);
    dl->AddRect(r.Min, r.Max, col,   rnd, 0, 1.6f);
}

// ── Corner box ───────────────────────────────────────────────────────────────
void visuals::dbox_corner(ImDrawList* dl, const ImRect& r, float alpha) {
    ImU32 col   = esp_col32a(cfg::esp::box_col, cfg::esp::box_rgb,
                             (int)(cfg::esp::box_col.w * alpha * 255.f), 0.3f);
    ImU32 black = IM_COL32(0, 0, 0, (int)(255 * alpha));
    float w  = r.Max.x - r.Min.x;
    float h  = r.Max.y - r.Min.y;
    float cl = fminf(w, h) * 0.25f;

    // TL
    dl->AddLine(ImVec2(r.Min.x,      r.Min.y),      ImVec2(r.Min.x + cl, r.Min.y),      black, 2.8f);
    dl->AddLine(ImVec2(r.Min.x,      r.Min.y),      ImVec2(r.Min.x,      r.Min.y + cl), black, 2.8f);
    dl->AddLine(ImVec2(r.Min.x,      r.Min.y),      ImVec2(r.Min.x + cl, r.Min.y),      col,   1.6f);
    dl->AddLine(ImVec2(r.Min.x,      r.Min.y),      ImVec2(r.Min.x,      r.Min.y + cl), col,   1.6f);
    // TR
    dl->AddLine(ImVec2(r.Max.x,      r.Min.y),      ImVec2(r.Max.x - cl, r.Min.y),      black, 2.8f);
    dl->AddLine(ImVec2(r.Max.x,      r.Min.y),      ImVec2(r.Max.x,      r.Min.y + cl), black, 2.8f);
    dl->AddLine(ImVec2(r.Max.x,      r.Min.y),      ImVec2(r.Max.x - cl, r.Min.y),      col,   1.6f);
    dl->AddLine(ImVec2(r.Max.x,      r.Min.y),      ImVec2(r.Max.x,      r.Min.y + cl), col,   1.6f);
    // BL
    dl->AddLine(ImVec2(r.Min.x,      r.Max.y),      ImVec2(r.Min.x + cl, r.Max.y),      black, 2.8f);
    dl->AddLine(ImVec2(r.Min.x,      r.Max.y),      ImVec2(r.Min.x,      r.Max.y - cl), black, 2.8f);
    dl->AddLine(ImVec2(r.Min.x,      r.Max.y),      ImVec2(r.Min.x + cl, r.Max.y),      col,   1.6f);
    dl->AddLine(ImVec2(r.Min.x,      r.Max.y),      ImVec2(r.Min.x,      r.Max.y - cl), col,   1.6f);
    // BR
    dl->AddLine(ImVec2(r.Max.x,      r.Max.y),      ImVec2(r.Max.x - cl, r.Max.y),      black, 2.8f);
    dl->AddLine(ImVec2(r.Max.x,      r.Max.y),      ImVec2(r.Max.x,      r.Max.y - cl), black, 2.8f);
    dl->AddLine(ImVec2(r.Max.x,      r.Max.y),      ImVec2(r.Max.x - cl, r.Max.y),      col,   1.6f);
    dl->AddLine(ImVec2(r.Max.x,      r.Max.y),      ImVec2(r.Max.x,      r.Max.y - cl), col,   1.6f);
}

// ── Fill (normal / gradient) ──────────────────────────────────────────────────
void visuals::dbox_fill(ImDrawList* dl, const ImRect& r) {
    if (!cfg::esp::box_fill) return;
    float rnd = cfg::esp::box_rounding;
    int   a   = (int)(cfg::esp::fill_alpha * 255.f);

    if (cfg::esp::fill_type == 1) {
        ImVec4 ct4, cb4;
        if (cfg::esp::fill_rgb) {
            ct4 = cfg::rgb::color4(0.0f); ct4.w = cfg::esp::fill_alpha;
            cb4 = cfg::rgb::color4(0.5f); cb4.w = cfg::esp::fill_alpha;
        } else {
            ct4 = ImVec4(cfg::esp::fill_col_top.x, cfg::esp::fill_col_top.y,
                         cfg::esp::fill_col_top.z, cfg::esp::fill_alpha);
            cb4 = ImVec4(cfg::esp::fill_col_bot.x, cfg::esp::fill_col_bot.y,
                         cfg::esp::fill_col_bot.z, cfg::esp::fill_alpha);
        }
        ImU32 cu = IM_COL32((int)(ct4.x*255),(int)(ct4.y*255),(int)(ct4.z*255),(int)(ct4.w*255));
        ImU32 cl = IM_COL32((int)(cb4.x*255),(int)(cb4.y*255),(int)(cb4.z*255),(int)(cb4.w*255));
        draw_gradient_rounded(dl, r.Min, r.Max, cu, cl, rnd);
    } else {
        ImU32 col = esp_col32a(cfg::esp::fill_col, cfg::esp::fill_rgb, a, 2.0f);
        dl->AddRectFilled(r.Min, r.Max, col, rnd);
    }
}

// ── ESP line (от низа экрана к игроку) ───────────────────────────────────────
void visuals::dline(ImDrawList* dl, const ImRect& r) {
    if (!cfg::esp::line) return;
    ImVec2 src((float)g_sw * 0.5f, (float)g_sh);
    ImVec2 dst((r.Min.x + r.Max.x) * 0.5f, r.Max.y);
    ImU32 col = esp_col32(cfg::esp::line_col, cfg::esp::line_rgb, 1.5f);
    dl->AddLine(src, dst, IM_COL32(0,0,0,150), 2.2f);
    dl->AddLine(src, dst, col,                  1.2f);
}

// ── Head circle ──────────────────────────────────────────────────────────────
void visuals::dhead_circle(ImDrawList* dl, const ImRect& r) {
    if (!cfg::esp::head_circle) return;
    float w      = r.Max.x - r.Min.x;
    float radius = w * 0.22f;
    if (radius < 2.f) radius = 2.f;
    // Над головой: центр на r.Min.y - radius (выше бокса)
    // Опускаем внутрь бокса: центр на r.Min.y + radius
    ImVec2 center((r.Min.x + r.Max.x) * 0.5f, r.Min.y + radius);
    ImU32 col = esp_col32(cfg::esp::head_circle_col, cfg::esp::head_circle_rgb, 0.f);
    dl->AddCircle(center, radius + 1.5f, IM_COL32(0,0,0,200), 20, 1.8f);
    dl->AddCircle(center, radius,        col,                   20, 1.2f);
}

// ── Distance text (справа от бокса) ──────────────────────────────────────────
void visuals::ddist(ImDrawList* dl, const ImRect& r, float dist) {
    if (!cfg::esp::distance) return;
    char buf[16];
    int dm = (int)(dist + 0.5f);
    if (dm < 0) dm = 0;
    snprintf(buf, sizeof(buf), "%dm", dm);
    ImVec2 tsz = ImGui::CalcTextSize(buf);
    float  tx  = r.Max.x + 5.f;
    float  ty  = (r.Min.y + r.Max.y) * 0.5f - tsz.y * 0.5f;
    ImU32 col = esp_col32(cfg::esp::distance_col, cfg::esp::distance_rgb, 0.f);
    dl->AddText(ImVec2(tx + 1.f, ty + 1.f), IM_COL32(0,0,0,255), buf);
    dl->AddText(ImVec2(tx,       ty),        col,                  buf);
}

// ── Nickname (над боксом) ─────────────────────────────────────────────────────
void visuals::dnick(ImDrawList* dl, const ImRect& r, const char* nick) {
    if (!cfg::esp::name || !nick || nick[0] == '\0') return;
    ImVec2 tsz = ImGui::CalcTextSize(nick);
    float  tx  = (r.Min.x + r.Max.x) * 0.5f - tsz.x * 0.5f;
    float  ty  = r.Min.y - tsz.y - 5.0f;
    ImU32 col = esp_col32(cfg::esp::name_col, cfg::esp::name_rgb, 0.6f);
    dl->AddText(ImVec2(tx + 1.f, ty + 1.f), IM_COL32(0,0,0,255), nick);
    dl->AddText(ImVec2(tx,       ty),        col,                  nick);
}

// ── HP bar (слева от бокса) ───────────────────────────────────────────────────
void visuals::dhp_bar(ImDrawList* dl, const ImRect& r, int hp) {
    if (!cfg::esp::health) return;
    float bw  = 3.0f;
    float bh  = r.Max.y - r.Min.y;
    float bx  = r.Min.x - bw - 5.0f;
    float by  = r.Min.y;
    dl->AddRectFilled(ImVec2(bx, by), ImVec2(bx + bw, by + bh), IM_COL32(0,0,0,200));
    float pct = hp / 100.0f;
    if (pct > 1.f) pct = 1.f;
    if (pct < 0.f) pct = 0.f;
    float hpH = bh * pct;
    float hpY = by + (bh - hpH);
    ImU32 col;
    if (cfg::esp::health_rgb) {
        col = esp_col32(cfg::esp::health_col, true, 1.0f);
    } else {
        col = IM_COL32(
            (int)(cfg::esp::health_col.x * 255),
            (int)(cfg::esp::health_col.y * 255),
            (int)(cfg::esp::health_col.z * 255), 255);
    }
    dl->AddRectFilled(ImVec2(bx, hpY), ImVec2(bx + bw, by + bh), col);
    dl->AddRect(ImVec2(bx, by), ImVec2(bx + bw, by + bh), IM_COL32(0,0,0,255), 0, 0, 1.0f);
}

// ── HP text (под боксом) ──────────────────────────────────────────────────────
void visuals::dhp_text(ImDrawList* dl, const ImRect& r, int hp) {
    if (!cfg::esp::health_text) return;
    char buf[16];
    snprintf(buf, sizeof(buf), "%d HP", hp);
    ImVec2 tsz = ImGui::CalcTextSize(buf);
    float  tx  = (r.Min.x + r.Max.x) * 0.5f - tsz.x * 0.5f;
    float  ty  = r.Max.y + 5.0f;
    ImU32 col;
    if (cfg::esp::hptext_rgb) {
        col = esp_col32(cfg::esp::hptext_col, true, 1.2f);
    } else {
        col = IM_COL32(
            (int)(cfg::esp::hptext_col.x * 255),
            (int)(cfg::esp::hptext_col.y * 255),
            (int)(cfg::esp::hptext_col.z * 255), 255);
    }
    dl->AddText(ImVec2(tx + 1.f, ty + 1.f), IM_COL32(0,0,0,255), buf);
    dl->AddText(ImVec2(tx,       ty),        col,                  buf);
}


// ── Crosshair (8 типов) ───────────────────────────────────────────────────────
// ── Fake Skeleton (пропорции от бокса) ───────────────────────────────────────
void visuals::dskeleton(ImDrawList* dl, const ImRect& r) {
    if (!cfg::esp::skeleton) return;

    float w   = r.Max.x - r.Min.x;
    float h   = r.Max.y - r.Min.y;
    float cx  = (r.Min.x + r.Max.x) * 0.5f;
    float top = r.Min.y;
    float bot = r.Max.y;

    ImU32 col = esp_col32(cfg::esp::skeleton_col, cfg::esp::skeleton_rgb, 0.f);

    // head circle radius = w * 0.22 — голова заканчивается на top + w*0.44
    // шея начинается ниже головы
    float hcr = w * 0.22f;  // head circle radius (совпадает с dhead_circle)

    ImVec2 neck   (cx,              top + hcr * 2.0f);
    ImVec2 chest  (cx,              top + h * 0.28f);
    ImVec2 pelvis (cx,              top + h * 0.55f);

    // Руки — не выходят за бокс, плечи на уровне груди
    ImVec2 l_shldr(cx - w * 0.38f,  top + h * 0.28f);
    ImVec2 l_elbow(cx - w * 0.44f,  top + h * 0.42f);
    ImVec2 l_hand (cx - w * 0.38f,  top + h * 0.55f);

    ImVec2 r_shldr(cx + w * 0.38f,  top + h * 0.28f);
    ImVec2 r_elbow(cx + w * 0.44f,  top + h * 0.42f);
    ImVec2 r_hand (cx + w * 0.38f,  top + h * 0.55f);

    // Ноги — узкие, расходятся от паха
    ImVec2 l_hip  (cx - w * 0.14f,  top + h * 0.55f);
    ImVec2 l_knee (cx - w * 0.16f,  top + h * 0.76f);
    ImVec2 l_foot (cx - w * 0.13f,  bot);

    ImVec2 r_hip  (cx + w * 0.14f,  top + h * 0.55f);
    ImVec2 r_knee (cx + w * 0.16f,  top + h * 0.76f);
    ImVec2 r_foot (cx + w * 0.13f,  bot);

    // ── Позвоночник ───────────────────────────────────────────
    skel_line(dl, col, neck,   chest);
    skel_line(dl, col, chest,  pelvis);

    // ── Ключицы ───────────────────────────────────────────────
    skel_line(dl, col, chest,   l_shldr);
    skel_line(dl, col, chest,   r_shldr);

    // ── Руки ─────────────────────────────────────────────────
    skel_line(dl, col, l_shldr, l_elbow);
    skel_line(dl, col, l_elbow, l_hand);
    skel_line(dl, col, r_shldr, r_elbow);
    skel_line(dl, col, r_elbow, r_hand);

    // ── Таз ──────────────────────────────────────────────────
    skel_line(dl, col, pelvis, l_hip);
    skel_line(dl, col, pelvis, r_hip);

    // ── Ноги ─────────────────────────────────────────────────
    skel_line(dl, col, l_hip,  l_knee);
    skel_line(dl, col, l_knee, l_foot);
    skel_line(dl, col, r_hip,  r_knee);
    skel_line(dl, col, r_knee, r_foot);
}

void visuals::dcrosshair(ImDrawList* fg) {
    if (!cfg::crosshair::enabled) return;

    float cx = g_sw * 0.5f;
    float cy = g_sh * 0.5f;

    float angle = cfg::crosshair::spin
        ? ((float)ImGui::GetTime() * cfg::crosshair::spin_speed)
        : 0.f;

    ImU32 col;
    if (cfg::crosshair::rgb) {
        col = cfg::rgb::color32((int)(cfg::crosshair::color.w * 255.f), 0.7f);
    } else {
        col = IM_COL32(
            (int)(cfg::crosshair::color.x * 255),
            (int)(cfg::crosshair::color.y * 255),
            (int)(cfg::crosshair::color.z * 255),
            (int)(cfg::crosshair::color.w * 255));
    }

    ImU32 outline = IM_COL32(0, 0, 0, 200);
    float s = cfg::crosshair::size;
    float t = cfg::crosshair::thick;
    float g = cfg::crosshair::gap;

    switch (cfg::crosshair::type) {

    case 0: { // Dot (+орбита при spin)
        float rad = t * 1.5f;
        if (cfg::crosshair::outline)
            fg->AddCircleFilled(ImVec2(cx, cy), rad + 1.2f, outline, 16);
        fg->AddCircleFilled(ImVec2(cx, cy), rad, col, 16);
        if (cfg::crosshair::spin) {
            float orbit = s * 0.9f;
            ImVec2 sat = rotate_around(cx, cy, orbit, 0.f, angle);
            if (cfg::crosshair::outline)
                fg->AddCircleFilled(sat, rad * 0.7f + 1.f, outline, 8);
            fg->AddCircleFilled(sat, rad * 0.7f, col, 8);
        }
        break;
    }

    case 1: { // Cross (классический)
        ImVec2 l1 = rotate_around(cx, cy, -s,  0.f, angle);
        ImVec2 l2 = rotate_around(cx, cy, -g,  0.f, angle);
        ImVec2 r1 = rotate_around(cx, cy,  g,  0.f, angle);
        ImVec2 r2 = rotate_around(cx, cy,  s,  0.f, angle);
        ImVec2 u1 = rotate_around(cx, cy, 0.f, -s,  angle);
        ImVec2 u2 = rotate_around(cx, cy, 0.f, -g,  angle);
        ImVec2 d1 = rotate_around(cx, cy, 0.f,  g,  angle);
        ImVec2 d2 = rotate_around(cx, cy, 0.f,  s,  angle);
        if (cfg::crosshair::outline) {
            fg->AddLine(l1, l2, outline, t + 2.f);
            fg->AddLine(r1, r2, outline, t + 2.f);
            fg->AddLine(u1, u2, outline, t + 2.f);
            fg->AddLine(d1, d2, outline, t + 2.f);
        }
        fg->AddLine(l1, l2, col, t);
        fg->AddLine(r1, r2, col, t);
        fg->AddLine(u1, u2, col, t);
        fg->AddLine(d1, d2, col, t);
        break;
    }

    case 2: { // Circle (+ tick при spin)
        if (cfg::crosshair::outline)
            fg->AddCircle(ImVec2(cx, cy), s + 1.5f, outline, 32, t + 2.f);
        fg->AddCircle(ImVec2(cx, cy), s, col, 32, t);
        if (cfg::crosshair::spin) {
            ImVec2 ta = rotate_around(cx, cy, 0.f, -(s + t + 3.f), angle);
            ImVec2 tb = rotate_around(cx, cy, 0.f, -(s - t - 1.f), angle);
            if (cfg::crosshair::outline)
                fg->AddLine(ta, tb, outline, t + 2.f);
            fg->AddLine(ta, tb, col, t + 0.5f);
        }
        break;
    }

    case 3: { // Horizontal + dot
        ImVec2 ba = rotate_around(cx, cy, -s, 0.f, angle);
        ImVec2 bb = rotate_around(cx, cy,  s, 0.f, angle);
        if (cfg::crosshair::outline)
            fg->AddLine(ba, bb, outline, t + 2.f);
        fg->AddLine(ba, bb, col, t);
        if (cfg::crosshair::outline)
            fg->AddCircleFilled(ImVec2(cx, cy), t * 0.6f + 1.f, outline, 8);
        fg->AddCircleFilled(ImVec2(cx, cy), t * 0.6f, col, 8);
        break;
    }

    case 4: { // V-shape
        float hs = s * 0.55f;
        ImVec2 tl  = rotate_around(cx, cy, -s,  -hs, angle);
        ImVec2 tr  = rotate_around(cx, cy,  s,  -hs, angle);
        ImVec2 bot = rotate_around(cx, cy, 0.f,  hs, angle);
        if (cfg::crosshair::outline) {
            fg->AddLine(tl, bot, outline, t + 2.f);
            fg->AddLine(tr, bot, outline, t + 2.f);
        }
        fg->AddLine(tl, bot, col, t);
        fg->AddLine(tr, bot, col, t);
        if (cfg::crosshair::outline)
            fg->AddCircleFilled(bot, t * 0.7f + 1.f, outline, 8);
        fg->AddCircleFilled(bot, t * 0.7f, col, 8);
        break;
    }

    case 5: { // Diamond
        ImVec2 tp = rotate_around(cx, cy, 0.f, -s,  angle);
        ImVec2 rp = rotate_around(cx, cy,  s,  0.f, angle);
        ImVec2 bp = rotate_around(cx, cy, 0.f,  s,  angle);
        ImVec2 lp = rotate_around(cx, cy, -s,  0.f, angle);
        if (cfg::crosshair::outline) {
            fg->AddLine(tp, rp, outline, t + 2.f);
            fg->AddLine(rp, bp, outline, t + 2.f);
            fg->AddLine(bp, lp, outline, t + 2.f);
            fg->AddLine(lp, tp, outline, t + 2.f);
        }
        fg->AddLine(tp, rp, col, t);
        fg->AddLine(rp, bp, col, t);
        fg->AddLine(bp, lp, col, t);
        fg->AddLine(lp, tp, col, t);
        break;
    }

    case 6: { // Star cross (8 лучей)
        float a45 = angle + 0.7854f;
        float ss  = s * 0.65f;
        float gg  = g * 0.65f;

        ImVec2 l1  = rotate_around(cx, cy, -s,   0.f, angle);
        ImVec2 l2  = rotate_around(cx, cy, -g,   0.f, angle);
        ImVec2 r1  = rotate_around(cx, cy,  g,   0.f, angle);
        ImVec2 r2  = rotate_around(cx, cy,  s,   0.f, angle);
        ImVec2 u1  = rotate_around(cx, cy, 0.f,  -s,  angle);
        ImVec2 u2  = rotate_around(cx, cy, 0.f,  -g,  angle);
        ImVec2 d1  = rotate_around(cx, cy, 0.f,   g,  angle);
        ImVec2 d2  = rotate_around(cx, cy, 0.f,   s,  angle);
        ImVec2 dl1 = rotate_around(cx, cy, -ss,  0.f, a45);
        ImVec2 dl2 = rotate_around(cx, cy, -gg,  0.f, a45);
        ImVec2 dr1 = rotate_around(cx, cy,  gg,  0.f, a45);
        ImVec2 dr2 = rotate_around(cx, cy,  ss,  0.f, a45);
        ImVec2 du1 = rotate_around(cx, cy, 0.f,  -ss, a45);
        ImVec2 du2 = rotate_around(cx, cy, 0.f,  -gg, a45);
        ImVec2 dd1 = rotate_around(cx, cy, 0.f,   gg, a45);
        ImVec2 dd2 = rotate_around(cx, cy, 0.f,   ss, a45);

        if (cfg::crosshair::outline) {
            fg->AddLine(l1,  l2,  outline, t + 2.f);
            fg->AddLine(r1,  r2,  outline, t + 2.f);
            fg->AddLine(u1,  u2,  outline, t + 2.f);
            fg->AddLine(d1,  d2,  outline, t + 2.f);
            fg->AddLine(dl1, dl2, outline, t + 1.5f);
            fg->AddLine(dr1, dr2, outline, t + 1.5f);
            fg->AddLine(du1, du2, outline, t + 1.5f);
            fg->AddLine(dd1, dd2, outline, t + 1.5f);
        }
        fg->AddLine(l1,  l2,  col, t);
        fg->AddLine(r1,  r2,  col, t);
        fg->AddLine(u1,  u2,  col, t);
        fg->AddLine(d1,  d2,  col, t);
        fg->AddLine(dl1, dl2, col, t * 0.8f);
        fg->AddLine(dr1, dr2, col, t * 0.8f);
        fg->AddLine(du1, du2, col, t * 0.8f);
        fg->AddLine(dd1, dd2, col, t * 0.8f);
        break;
    }

    case 7: { // T-shape
        ImVec2 tl = rotate_around(cx, cy, -s,  -g,  angle);
        ImVec2 tr = rotate_around(cx, cy,  s,  -g,  angle);
        ImVec2 tc = rotate_around(cx, cy, 0.f, -g,  angle);
        ImVec2 bc = rotate_around(cx, cy, 0.f,  s,  angle);
        if (cfg::crosshair::outline) {
            fg->AddLine(tl, tr, outline, t + 2.f);
            fg->AddLine(tc, bc, outline, t + 2.f);
        }
        fg->AddLine(tl, tr, col, t);
        fg->AddLine(tc, bc, col, t);
        if (cfg::crosshair::outline)
            fg->AddCircleFilled(ImVec2(cx, cy), t * 0.55f + 1.f, outline, 8);
        fg->AddCircleFilled(ImVec2(cx, cy), t * 0.55f, col, 8);
        break;
    }

    } // switch
}

// ─────────────────────────────────────────────────────────────────────────────
//  MAIN DRAW LOOP
// ─────────────────────────────────────────────────────────────────────────────
void visuals::draw() {
    bool any = cfg::esp::box       ||
               cfg::esp::name      || cfg::esp::health      ||
               cfg::esp::health_text || cfg::esp::distance  ||
               cfg::esp::line      || cfg::esp::head_circle ||
               cfg::esp::skeleton  || cfg::esp::box_fill    ||
               cfg::crosshair::enabled;
    if (!any) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    // ── Crosshair (не привязан к игрокам) ────────────────────
    dcrosshair(dl);

    uint64_t PlayerManager = get_player_manager();
    if (!PlayerManager) return;

    uint64_t LocalPlayer = rpm<uint64_t>(PlayerManager + oxorany(OFF_PM_LOCAL_PLAYER));
    if (!LocalPlayer) return;

    matrix    ViewMatrix     = player::view_matrix(LocalPlayer);
    Vector3   LocalPosition  = player::position(LocalPlayer);
    int       LocalTeam      = rpm<uint8_t>(LocalPlayer + oxorany(OFF_PLAYER_TEAM));

    uint64_t PlayerList = rpm<uint64_t>(PlayerManager + oxorany(OFF_PM_PLAYER_LIST));
    if (!PlayerList) return;

    int PlayerCount = rpm<int>(PlayerList + oxorany(OFF_LIST_COUNT));
    if (PlayerCount <= 0 || PlayerCount > 64) return;

    uint64_t ListBuffer = rpm<uint64_t>(PlayerList + oxorany(OFF_LIST_BUFFER));
    if (!ListBuffer) return;

    for (int i = 0; i < PlayerCount; i++) {
        uint64_t Player = rpm<uint64_t>(
            ListBuffer + oxorany(OFF_LIST_ENTRY_BASE) +
            (uint64_t)oxorany(OFF_LIST_ENTRY_STRIDE) * (uint64_t)i);
        if (!Player || Player == LocalPlayer) continue;

        uint8_t PlayerTeam = rpm<uint8_t>(Player + oxorany(OFF_PLAYER_TEAM));
        if (PlayerTeam == (uint8_t)LocalTeam) continue;

        int Health = player::health(Player);
        if (Health <= 0) continue;

        Vector3 PlayerPosition = player::position(Player);
        if (PlayerPosition.x == 0.f && PlayerPosition.y == 0.f &&
            PlayerPosition.z == 0.f) continue;

        float Distance = calculate_distance(PlayerPosition, LocalPosition);
        if (Distance > 500.f) continue;

        Vector3 HeadPosition(PlayerPosition.x,
                             PlayerPosition.y + PLAYER_HEIGHT,
                             PlayerPosition.z);

        ImVec2 ScreenHead, ScreenFoot;
        if (!world_to_screen(HeadPosition,    ViewMatrix, ScreenHead)) continue;
        if (!world_to_screen(PlayerPosition,  ViewMatrix, ScreenFoot)) continue;

        float bh = fabsf(ScreenFoot.y - ScreenHead.y);
        float bw = bh * 0.25f;
        float cx = (ScreenHead.x + ScreenFoot.x) * 0.5f;

        float y_top = ScreenHead.y < ScreenFoot.y ? ScreenHead.y : ScreenFoot.y;
        float y_bot = ScreenHead.y > ScreenFoot.y ? ScreenHead.y : ScreenFoot.y;

        ImRect r(ImVec2(cx - bw, y_top), ImVec2(cx + bw, y_bot));

        // порядок: fill → box → детали
        dbox_fill(dl, r);

        if (cfg::esp::box) {
            if (cfg::esp::box_type == 0) dbox_full  (dl, r, 1.f);
            else                         dbox_corner(dl, r, 1.f);
        }

        dline       (dl, r);
        dhead_circle(dl, r);
        ddist       (dl, r, Distance);

        if (cfg::esp::name) {
            read_string PlayerName = player::name(Player);
            std::string ns = PlayerName.as_utf8();
            if (!ns.empty()) dnick(dl, r, ns.c_str());
        }

        dhp_bar (dl, r, Health);
        dhp_text(dl, r, Health);
        dskeleton(dl, r);
    }
}

