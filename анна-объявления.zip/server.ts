import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_key_123';

// --- Database Setup ---
const db = new Database('anna_market.db');

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    displayName TEXT NOT NULL,
    photoURL TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS listings (
    id TEXT PRIMARY KEY,
    ownerId TEXT NOT NULL,
    ownerName TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    price REAL DEFAULT 0,
    type TEXT CHECK(type IN ('sale', 'exchange')) NOT NULL,
    category TEXT NOT NULL,
    images TEXT, -- JSON string array
    status TEXT CHECK(status IN ('active', 'sold', 'hidden')) DEFAULT 'active',
    location TEXT DEFAULT 'Анна',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(ownerId) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    recipientId TEXT NOT NULL,
    type TEXT CHECK(type IN ('message', 'response', 'update')) NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    link TEXT NOT NULL,
    read INTEGER DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(recipientId) REFERENCES users(id)
  );
`);

async function startServer() {
  const app = express();
  app.use(express.json());
  app.use(cors());

  // --- Middleware: Auth ---
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ error: 'Unauthorized' });

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.status(403).json({ error: 'Forbidden' });
      req.user = user;
      next();
    });
  };

  // --- Auth Routes ---
  app.post('/api/auth/register', async (req, res) => {
    const { email, password, displayName } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const userId = Math.random().toString(36).substring(2, 11);
      
      const stmt = db.prepare('INSERT INTO users (id, email, password, displayName) VALUES (?, ?, ?, ?)');
      stmt.run(userId, email, hashedPassword, displayName);

      // Create welcome notification immediately
      const notifId = Math.random().toString(36).substring(2, 11);
      db.prepare(`
        INSERT INTO notifications (id, recipientId, type, title, body, link)
        VALUES (?, ?, 'update', 'Добро пожаловать!', 'Спасибо за регистрацию на Анна.Маркет. Создайте свое первое объявление уже сегодня!', '/create')
      `).run(notifId, userId);

      const token = jwt.sign({ id: userId, email, displayName }, JWT_SECRET);
      res.json({ token, user: { id: userId, email, displayName } });
    } catch (e: any) {
      if (e.message.includes('UNIQUE')) return res.status(400).json({ error: 'Email already exists' });
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as any;

    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ id: user.id, email: user.email, displayName: user.displayName }, JWT_SECRET);
    res.json({ token, user: { id: user.id, email: user.email, displayName: user.displayName } });
  });

  app.get('/api/auth/me', authenticateToken, (req: any, res) => {
    const user = db.prepare('SELECT id, email, displayName, photoURL FROM users WHERE id = ?').get(req.user.id);
    res.json(user);
  });

  // --- Listing Routes ---
  app.get('/api/listings', (req, res) => {
    const { category } = req.query;
    let listings;
    try {
      if (category && category !== 'all') {
        listings = db.prepare("SELECT * FROM listings WHERE status = 'active' AND category = ? ORDER BY createdAt DESC").all(category);
      } else {
        listings = db.prepare("SELECT * FROM listings WHERE status = 'active' ORDER BY createdAt DESC").all();
      }
      res.json(listings.map((l: any) => ({ ...l, images: JSON.parse(l.images || '[]') })));
    } catch (e: any) {
      console.error('Listings Fetch Error:', e);
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/listings/:id', (req, res) => {
    const listing = db.prepare('SELECT * FROM listings WHERE id = ?').get(req.params.id) as any;
    if (!listing) return res.status(404).json({ error: 'Not found' });
    res.json({ ...listing, images: JSON.parse(listing.images || '[]') });
  });

  app.delete('/api/listings/:id', authenticateToken, (req: any, res) => {
    const listingId = req.params.id;
    const listing = db.prepare('SELECT ownerId FROM listings WHERE id = ?').get(listingId) as any;
    
    if (!listing) return res.status(404).json({ error: 'Not found' });
    if (listing.ownerId !== req.user.id) return res.status(403).json({ error: 'Forbidden' });

    db.prepare('DELETE FROM listings WHERE id = ?').run(listingId);
    res.json({ success: true });
  });

  app.post('/api/listings', authenticateToken, (req: any, res) => {
    const { title, description, price, type, category, images } = req.body;
    const id = Math.random().toString(36).substring(2, 11);
    
    const stmt = db.prepare(`
      INSERT INTO listings (id, ownerId, ownerName, title, description, price, type, category, images)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(id, req.user.id, req.user.displayName, title, description, price, type, category, JSON.stringify(images || []));
    
    res.json({ id });
  });

  app.get('/api/my-listings', authenticateToken, (req: any, res) => {
    const listings = db.prepare('SELECT * FROM listings WHERE ownerId = ?').all(req.user.id);
    res.json(listings.map((l: any) => ({ ...l, images: JSON.parse(l.images || '[]') })));
  });

  // --- Notification Routes ---
  app.get('/api/notifications', authenticateToken, (req: any, res) => {
    const notifications = db.prepare('SELECT * FROM notifications WHERE recipientId = ? ORDER BY createdAt DESC LIMIT 50').all(req.user.id);
    res.json(notifications);
  });

  app.post('/api/notifications/mark-read', authenticateToken, (req: any, res) => {
    const { id } = req.body;
    db.prepare('UPDATE notifications SET read = 1 WHERE id = ? AND recipientId = ?').run(id, req.user.id);
    res.json({ success: true });
  });

  app.post('/api/notifications', authenticateToken, (req: any, res) => {
    const { recipientId, type, title, body, link } = req.body;
    const id = Math.random().toString(36).substring(2, 11);
    db.prepare(`
      INSERT INTO notifications (id, recipientId, type, title, body, link)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, recipientId, type, title, body, link);
    res.json({ id });
  });

  // --- Vite / Static ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
