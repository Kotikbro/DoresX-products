/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  photoURL?: string;
  createdAt: any;
  notificationSettings: {
    messages: boolean;
    responses: boolean;
    updates: boolean;
    email: boolean;
  };
}

export type ListingType = 'sale' | 'exchange';
export type ListingStatus = 'active' | 'sold' | 'hidden';

export interface Listing {
  id: string;
  ownerId: string;
  ownerName: string;
  title: string;
  description: string;
  price: number;
  type: ListingType;
  category: string;
  images: string[];
  createdAt: any;
  updatedAt: any;
  status: ListingStatus;
  location: string;
}

export interface Chat {
  id: string;
  listingId: string;
  listingTitle: string;
  participantIds: string[];
  lastMessage?: string;
  lastUpdatedAt: any;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  createdAt: any;
  readBy: string[];
}

export type NotificationType = 'message' | 'response' | 'update';

export interface Notification {
  id: string;
  recipientId: string;
  type: NotificationType;
  title: string;
  body: string;
  link: string;
  read: boolean;
  createdAt: any;
}
