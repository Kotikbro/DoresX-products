/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Header from './components/layout/Header';
import Home from './pages/Home';
import AuthPage from './pages/Auth';
import CreateListing from './pages/CreateListing';
import ListingDetails from './pages/ListingDetails';
import ProfilePage from './pages/Profile';

export default function App() {
  const [path, setPath] = useState(window.location.pathname);

  useEffect(() => {
    const handlePopState = () => setPath(window.location.pathname);
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const renderPage = () => {
    if (path.startsWith('/auth')) return <AuthPage />;
    if (path.startsWith('/create')) return <CreateListing />;
    if (path.startsWith('/profile')) return <ProfilePage />;
    if (path.startsWith('/listing/')) return <ListingDetails listingId={path.split('/').pop() || ''} />;
    return <Home />;
  };

  return (
    <div className="min-h-screen bg-brand-bg font-sans selection:bg-blue-100 selection:text-primary">
      <Header />
      <main className="animate-in fade-in duration-500">
        {renderPage()}
      </main>
      
      {/* Compact Footer */}
      <footer className="h-14 bg-white border-t border-gray-200 flex items-center justify-between px-6 text-[10px] text-gray-500 shrink-0 mt-auto">
        <div>&copy; 2026 Анна.Маркет — Доска объявлений Аннинского района</div>
        <div className="flex gap-6 font-bold uppercase tracking-widest">
          <span className="hover:text-primary cursor-pointer transition-colors">Реклама на сайте</span>
          <span className="hover:text-primary cursor-pointer transition-colors">Пользовательское соглашение</span>
          <span className="hover:text-primary cursor-pointer transition-colors">Безопасная сделка</span>
        </div>
      </footer>
    </div>
  );
}
