import React, { useState, useEffect } from 'react';
import { 
  MessageSquare, 
  User as UserIcon, 
  MapPin, 
  ArrowRightLeft, 
  ChevronLeft,
  Send,
  Loader2,
  Tag
} from 'lucide-react';
import { api, getStoredUser } from '../lib/api';
import { Listing } from '../types';
import { formatPrice } from '../lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { ru } from 'date-fns/locale';

export default function ListingDetails({ listingId }: { listingId: string }) {
  const user = getStoredUser();
  const [listing, setListing] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [success, setSuccess] = useState(false);
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    const fetch = async () => {
      try {
        const data = await api.get(`/listings/${listingId}`);
        setListing(data);
      } catch (e) {
        console.error(e);
      }
      setLoading(false);
    };
    fetch();
  }, [listingId]);

  const handleSendMessage = async () => {
    if (!user || !listing || !message) return;
    setSending(true);
    
    try {
      // Create a notification for the listing owner
      await api.post('/notifications', {
        recipientId: listing.ownerId,
        type: 'message',
        title: 'Новое сообщение',
        body: `${user.displayName || 'Покупатель'} интересуется вашим объявлением "${listing.title}": "${message}"`,
        link: `/listing/${listing.id}`
      });

      setSuccess(true);
      setMessage('');
    } catch (e) {
      console.error(e);
      alert('Ошибка при отправке');
    } finally {
      setSending(false);
    }
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-gray-400">
      <Loader2 className="animate-spin mb-4" size={48} />
      <span>Загрузка объявления...</span>
    </div>
  );

  if (!listing) return <div className="p-20 text-center">Объявление не найдено</div>;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 bg-brand-bg md:min-h-screen">
      <button 
        onClick={() => window.location.href = '/'}
        className="flex items-center text-gray-400 hover:text-black mb-8 font-bold text-xs uppercase tracking-widest transition-colors"
      >
        <ChevronLeft size={14} className="mr-1" /> На главную
      </button>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Left Column: Media & Description */}
        <div className="flex-1 space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
            <div className="aspect-video bg-gray-100 flex items-center justify-center relative">
              {listing.images?.length ? (
                <img 
                  src={listing.images[activeImage]} 
                  alt={listing.title}
                  className="w-full h-full object-contain"
                />
              ) : (
                <div className="text-gray-300 italic text-xs uppercase font-black tracking-widest">Нет изображений</div>
              )}
              {listing.type === 'exchange' && (
                <div className="absolute top-4 left-4 bg-accent text-white text-[10px] font-black px-3 py-1.5 rounded shadow-xl flex items-center gap-2 uppercase tracking-tighter">
                  <ArrowRightLeft size={12} /> ОБМЕН
                </div>
              )}
            </div>
            {listing.images && listing.images.length > 1 && (
              <div className="p-4 bg-gray-50 flex gap-3 border-t border-gray-100 overflow-x-auto">
                {listing.images.map((img, idx) => (
                  <button 
                    key={idx}
                    onClick={() => setActiveImage(idx)}
                    className={`w-20 aspect-square rounded-lg border-2 transition-all overflow-hidden shrink-0 ${activeImage === idx ? 'border-primary' : 'border-transparent opacity-60 hover:opacity-100'}`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-8 shadow-sm">
            <h2 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-6 border-b border-gray-100 pb-2">Описание</h2>
            <div className="prose prose-sm max-w-none text-gray-600 leading-relaxed whitespace-pre-wrap font-medium">
              {listing.description}
            </div>
          </div>
        </div>

        {/* Right Column: Actions & Details */}
        <div className="w-full lg:w-96 space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-8 shadow-sm sticky top-24">
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[10px] font-black text-primary uppercase tracking-widest bg-blue-50 px-2 py-0.5 rounded">{listing.category}</span>
              </div>
              <h1 className="text-3xl font-black text-gray-900 leading-tight tracking-tight mb-2">
                {listing.title}
              </h1>
              <div className="text-3xl font-black text-primary tracking-tighter">
                {listing.price === 0 ? 'Бесплатно' : `${listing.price.toLocaleString('ru-RU')} ₽`}
              </div>
            </div>

            <div className="space-y-4 mb-8">
              {user ? (
                 listing.ownerId !== user.id ? (
                   <div className="space-y-4">
                     {success ? (
                       <div className="p-4 bg-green-50 text-green-700 rounded-lg flex items-center gap-3 border border-green-100 italic font-medium text-sm">
                         <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center shrink-0">
                           <CheckCircle size={16} />
                         </div>
                         <span>Сообщение отправлено</span>
                       </div>
                     ) : (
                       <>
                         <textarea 
                           rows={3}
                           value={message}
                           onChange={(e) => setMessage(e.target.value)}
                           placeholder="Напишите продавцу..."
                           className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:bg-white focus:ring-4 focus:ring-primary/5 outline-none transition-all resize-none text-sm font-medium"
                         />
                         <button 
                           onClick={handleSendMessage}
                           disabled={sending || !message}
                           className="w-full bg-primary hover:bg-blue-600 text-white font-black py-4 rounded-lg shadow-lg shadow-blue-100 transition-all active:scale-[0.98] flex items-center justify-center gap-3"
                         >
                           {sending ? <Loader2 className="animate-spin" size={20} /> : <Send size={20} />}
                           Написать продавцу
                         </button>
                       </>
                     )}
                   </div>
                 ) : (
                   <div className="p-4 bg-blue-50 text-primary rounded-lg text-xs font-bold text-center border border-blue-100">
                     Это ваше объявление
                   </div>
                 )
              ) : (
                <button 
                  onClick={() => window.location.href = '/auth'}
                  className="w-full bg-primary hover:bg-blue-600 text-white font-black py-4 rounded-lg shadow-lg shadow-blue-100 transition-all active:scale-[0.98]"
                >
                  Войти, чтобы написать
                </button>
              )}
              
              <button className="w-full bg-white border-2 border-gray-200 text-gray-500 hover:border-primary hover:text-primary font-black py-4 rounded-lg transition-all flex items-center justify-center gap-3">
                <MessageSquare size={20} />
                Предложить цену
              </button>
            </div>

            <div className="space-y-4 pt-6 border-t border-gray-100">
               <div className="flex items-center text-gray-400 text-xs">
                 <MapPin className="mr-3 text-primary" size={16} />
                 <span className="font-medium">{listing.location || 'ПГТ Анна, Воронежская обл.'}</span>
               </div>
               <div className="flex items-center text-gray-400 text-xs">
                 <Tag className="mr-3 text-primary" size={16} />
                 <span className="font-medium capitalize">{listing.category}</span>
               </div>
            </div>

            <div className="mt-8 pt-8 border-t border-gray-100">
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gray-100 rounded-full border border-gray-200 flex items-center justify-center text-gray-400">
                    <UserIcon size={24} />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-gray-900">{listing.userName || 'Продавец'}</div>
                    <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">ПГТ Анна • На сайте с 2026</div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CheckCircle(props: any) {
  return (
    <svg 
      {...props}
      xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" 
    >
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}
