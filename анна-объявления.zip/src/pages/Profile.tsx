/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  User as UserIcon, 
  Settings, 
  Bell, 
  Package, 
  LogOut,
  Mail,
  CheckCircle2
} from 'lucide-react';
import { api, getStoredUser, clearAuth } from '../lib/api';
import { Listing, UserProfile } from '../types';
import ListingCard from '../components/listings/ListingCard';
import { cn } from '../lib/utils';

export default function ProfilePage() {
  const [user, setUser] = useState(getStoredUser());
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [listings, setListings] = useState<Listing[]>([]);
  const [tab, setTab] = useState<'listings' | 'settings'>('listings');
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (!user) return;

    // Fetch Profile
    const fetchProfile = async () => {
      try {
        const data = await api.get('/auth/me');
        setProfile(data);
      } catch (e) {
        console.error(e);
      }
    };
    fetchProfile();

    // Fetch User Listings
    const fetchListings = async () => {
      try {
        const data = await api.get('/my-listings');
        setListings(data);
      } catch (e) {
        console.error(e);
      }
    };
    fetchListings();
  }, [user]);

  const updateSettings = async (key: string, value: boolean) => {
    // Note: We'll implement profile update in server.ts if needed, 
    // for now we'll just mock this or skip if too complex for demo
    console.log('Update setting', key, value);
  };
  
  const handleLogout = () => {
    clearAuth();
    setUser(null);
    window.location.href = '/';
  };

  if (!user) return <div className="p-20 text-center">Войдите в аккаунт</div>;

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row gap-12">
        {/* Sidebar */}
        <div className="w-full md:w-64 space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm text-center">
            <div className="w-20 h-20 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white shadow-md">
              {user.photoURL ? (
                <img src={user.photoURL} alt="Avatar" className="w-full h-full rounded-full object-cover" />
              ) : (
                <UserIcon size={40} />
              )}
            </div>
            <h2 className="font-bold text-gray-900">{user.displayName}</h2>
            <p className="text-xs text-gray-400 mt-1">{user.email}</p>
          </div>

          <nav className="flex flex-col gap-2">
            <button 
              onClick={() => setTab('listings')}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all",
                tab === 'listings' ? "bg-primary text-white shadow-lg shadow-blue-100" : "bg-white text-gray-500 hover:bg-gray-50"
              )}
            >
              <Package size={20} /> Мои объявления
            </button>
            <button 
              onClick={() => setTab('settings')}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all",
                tab === 'settings' ? "bg-primary text-white shadow-lg shadow-blue-100" : "bg-white text-gray-500 hover:bg-gray-50"
              )}
            >
              <Settings size={20} /> Настройки уведомлений
            </button>
            <button 
              onClick={handleLogout}
              className="flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-red-500 hover:bg-red-50 transition-all mt-4"
            >
              <LogOut size={20} /> Выйти
            </button>
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1">
          {tab === 'listings' ? (
            <div className="space-y-6">
               <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Мои объявления ({listings.length})</h2>
               {listings.length > 0 ? (
                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                   {listings.map(l => (
                     <div key={l.id}>
                       <ListingCard 
                         listing={l} 
                         onClick={() => { window.location.href = `/listing/${l.id}`; }}
                         onDelete={() => {
                           setListings(prev => prev.filter(item => item.id !== l.id));
                         }} 
                       />
                     </div>
                   ))}
                 </div>
               ) : (
                 <div className="py-20 text-center bg-white rounded-3xl border border-gray-100 shadow-sm">
                    <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-300">
                      <Package size={32} />
                    </div>
                    <p className="text-gray-900 font-bold">У вас пока нет объявлений</p>
                    <p className="text-gray-500 text-sm mt-1 mb-6">Самое время что-нибудь продать в Анне!</p>
                    <button 
                      onClick={() => window.location.href = '/create'} 
                      className="bg-primary text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-blue-50 hover:bg-blue-600 transition-all"
                    >
                      Разместить первое
                    </button>
                 </div>
               )}
            </div>
          ) : (
            <div className="space-y-8 bg-white rounded-3xl p-8 border border-gray-100 shadow-sm">
               <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2 tracking-tight">Уведомления</h2>
                  <p className="text-gray-500 text-sm">Выберите, какие уведомления вы хотите получать</p>
               </div>

               <div className="space-y-6">
                  <NotificationToggle 
                    title="Новые сообщения"
                    description="Когда кто-то пишет по поводу вашего объявления"
                    icon={<Bell size={20} />}
                    enabled={profile?.notificationSettings?.messages ?? true}
                    onToggle={(val) => updateSettings('messages', val)}
                    accent="blue"
                  />
                  <NotificationToggle 
                    title="Ответы на объявления"
                    description="Уведомления о новых откликах"
                    icon={<CheckCircle2 size={20} />}
                    enabled={profile?.notificationSettings?.responses ?? true}
                    onToggle={(val) => updateSettings('responses', val)}
                    accent="blue"
                  />
                  <NotificationToggle 
                    title="Новости сервиса"
                    description="Важные обновления и советы"
                    icon={<Settings size={20} />}
                    enabled={profile?.notificationSettings?.updates ?? true}
                    onToggle={(val) => updateSettings('updates', val)}
                    accent="blue"
                  />
                  <div className="pt-6 border-t border-gray-50">
                    <NotificationToggle 
                      title="Email-уведомления"
                      description="Дублировать важные уведомления на почту"
                      icon={<Mail size={20} />}
                      enabled={profile?.notificationSettings?.email ?? false}
                      onToggle={(val) => updateSettings('email', val)}
                      accent="blue"
                    />
                  </div>
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function NotificationToggle({ title, description, icon, enabled, onToggle, accent = 'blue' }: any) {
  return (
    <div className="flex items-center justify-between gap-4 group">
      <div className="flex gap-4">
        <div className={cn(
          "w-12 h-12 rounded-xl flex items-center justify-center transition-colors shrink-0",
          accent === 'orange' ? "bg-orange-50 text-orange-500" : "bg-blue-50 text-primary"
        )}>
          {icon}
        </div>
        <div>
          <h4 className="font-bold text-gray-900">{title}</h4>
          <p className="text-sm text-gray-400 font-medium">{description}</p>
        </div>
      </div>
      <button 
        onClick={() => onToggle(!enabled)}
        className={cn(
          "w-11 h-6 rounded-full relative transition-all duration-300 outline-none",
          enabled 
            ? (accent === 'orange' ? "bg-orange-500" : "bg-primary") 
            : "bg-gray-200"
        )}
      >
        <div className={cn(
          "absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 shadow-sm",
          enabled ? "left-6" : "left-1"
        )} />
      </button>
    </div>
  );
}
