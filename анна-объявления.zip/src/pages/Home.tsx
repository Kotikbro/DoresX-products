import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Car, 
  Smartphone, 
  Shirt, 
  Home as HomeIcon, 
  MoreHorizontal,
  ChevronRight,
  Sparkles,
  Search,
  User as UserIcon,
  Zap,
  Droplet,
  PlusSquare
} from 'lucide-react';
import ListingCard from '../components/listings/ListingCard';
import { api, getStoredUser } from '../lib/api';
import { Listing } from '../types';
import { cn } from '../lib/utils';

const CATEGORIES = [
  { id: 'all', name: 'Все', icon: <Sparkles size={20} /> },
  { id: 'vape-pods', name: 'Подики', icon: <Zap size={20} /> },
  { id: 'vape-liquids', name: 'Жижи', icon: <Droplet size={20} /> },
  { id: 'vape-acc', name: 'К подикам...', icon: <PlusSquare size={20} /> },
  { id: 'auto', name: 'Авто', icon: <Car size={20} /> },
  { id: 'realestate', name: 'Недвижимость', icon: <Building2 size={20} /> },
  { id: 'electronics', name: 'Электроника', icon: <Smartphone size={20} /> },
  { id: 'fashion', name: 'Одежда', icon: <Shirt size={20} /> },
  { id: 'home', name: 'Для дома', icon: <HomeIcon size={20} /> },
  { id: 'other', name: 'Прочее', icon: <MoreHorizontal size={20} /> },
];

export default function Home() {
  const user = getStoredUser();
  const [listings, setListings] = useState<Listing[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchListings = async () => {
      setLoading(true);
      try {
        const data = await api.get(`/listings?category=${selectedCategory}`);
        setListings(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };

    fetchListings();
  }, [selectedCategory]);

  return (
    <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-brand-bg">
      {/* Sidebar - Hidden on mobile */}
      <aside className="hidden md:block w-64 bg-white border-r border-gray-200 overflow-y-auto p-6 shrink-0 h-[calc(100vh-60px)] sticky top-[60px]">
        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">Категории</h3>
        <nav className="space-y-1">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={cn(
                "w-full flex items-center justify-between p-2.5 rounded-lg text-sm font-medium transition-all group",
                selectedCategory === cat.id 
                  ? "bg-blue-50 text-primary" 
                  : "text-gray-600 hover:bg-gray-50"
              )}
            >
              <div className="flex items-center gap-3">
                <span className={cn(
                   "transition-colors",
                   selectedCategory === cat.id ? "text-primary" : "text-gray-400 group-hover:text-gray-600"
                )}>
                  {cat.icon}
                </span>
                <span>{cat.name}</span>
              </div>
              {cat.id === 'exchange' && (
                <span className="text-[9px] font-black bg-accent text-white px-1 py-0.5 rounded tracking-tighter">NEW</span>
              )}
            </button>
          ))}
        </nav>

        {!user && (
          <div className="mt-8 p-5 bg-blue-50 rounded-xl border border-blue-100">
            <p className="text-xs text-primary font-bold mb-2 flex items-center gap-1">
              <UserIcon size={12} /> Авторизуйтесь
            </p>
            <p className="text-[10px] text-blue-600 leading-relaxed font-medium">
              Чтобы выкладывать свои объявления о продаже или обмене, необходимо войти в аккаунт.
            </p>
            <button 
              onClick={() => window.location.href = '/auth'}
              className="mt-3 text-[10px] font-bold text-primary hover:underline uppercase tracking-wider"
            >
              Войти сейчас
            </button>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-8">
        {/* Search Integration */}
        <div className="max-w-4xl mx-auto mb-10">
           <div className="flex gap-2 items-center bg-white p-1 rounded-xl shadow-sm border border-gray-200">
              <div className="flex-1 flex items-center bg-gray-50/50 rounded-lg px-4 border border-transparent focus-within:bg-white focus-within:border-primary/30 focus-within:ring-4 focus-within:ring-primary/5 transition-all">
                <input 
                  type="text" 
                  placeholder="Поиск по ПГТ Анна..." 
                  className="w-full py-3.5 outline-none text-base placeholder:text-gray-400 font-medium"
                />
                <Search className="text-gray-400" size={20} />
              </div>
              <button className="bg-primary text-white px-10 py-3.5 rounded-lg font-bold hover:bg-blue-600 transition-all shadow-lg shadow-blue-100">
                Найти
              </button>
           </div>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="flex items-baseline justify-between mb-8 pb-4 border-b border-gray-200/50">
            <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Рекомендации для вас в Анне</h2>
            <div className="flex gap-6 text-sm">
              <span className="font-bold text-primary underline decoration-primary underline-offset-8 cursor-pointer">По дате</span>
              <span className="text-gray-400 cursor-pointer hover:text-gray-900 transition-colors">Подешевле</span>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="animate-pulse bg-white rounded-xl p-3 border border-gray-100">
                  <div className="aspect-[4/3] bg-gray-100 rounded-lg mb-3" />
                  <div className="h-4 bg-gray-100 rounded w-1/4 mb-2" />
                  <div className="h-4 bg-gray-100 rounded w-3/4 mb-4" />
                  <div className="h-3 bg-gray-100 rounded w-1/2" />
                </div>
              ))}
            </div>
          ) : listings.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
              {listings.map((l) => (
                <div key={l.id}>
                  <ListingCard listing={l} onClick={() => { window.location.href = `/listing/${l.id}`; }} />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-24 bg-white rounded-2xl border border-gray-200 shadow-sm">
              <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-300">
                <Search size={32} />
              </div>
              <h3 className="text-lg font-bold text-gray-900">Объявлений пока нет</h3>
              <p className="text-gray-500 mt-1 mb-8">Станьте первым, кто разместит объявление в этой категории!</p>
              <button 
                onClick={() => window.location.href = '/create'}
                className="bg-primary text-white font-bold px-8 py-3 rounded-lg hover:bg-blue-600 transition-all shadow-lg shadow-blue-50"
              >
                Разместить объявление
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
