import React, { useState } from 'react';
import { 
  Camera, 
  MapPin, 
  Tag, 
  Package, 
  ArrowRightLeft,
  DollarSign,
  ChevronLeft,
  PlusSquare
} from 'lucide-react';
import { api, getStoredUser } from '../lib/api';

const CATEGORIES = [
  { id: 'vape-pods', name: 'Подики' },
  { id: 'vape-liquids', name: 'Жижи' },
  { id: 'vape-acc', name: 'К подикам...' },
  { id: 'auto', name: 'Авто' },
  { id: 'realestate', name: 'Недвижимость' },
  { id: 'electronics', name: 'Электроника' },
  { id: 'fashion', name: 'Одежда' },
  { id: 'home', name: 'Для дома' },
  { id: 'other', name: 'Прочее' },
];

export default function CreateListing() {
  const user = getStoredUser();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [type, setType] = useState<'sale' | 'exchange'>('sale');
  const [category, setCategory] = useState('other');
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState<string[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Файл слишком большой. Максимум 2МБ');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setImages(prev => [...prev, reader.result as string].slice(0, 4));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  if (!user) {
    return (
      <div className="max-w-md mx-auto mt-20 text-center p-8 bg-white rounded-3xl shadow-xl border border-gray-100">
        <div className="w-16 h-16 bg-orange-100 text-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Package size={32} />
        </div>
        <h2 className="text-2xl font-bold">Нужна авторизация</h2>
        <p className="text-gray-500 mt-2 mb-6">Чтобы разместить объявление, войдите в свой аккаунт</p>
        <button 
          onClick={() => window.location.href = '/auth'}
          className="w-full bg-orange-500 text-white font-bold py-3 rounded-xl"
        >
          Войти
        </button>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
        const res = await api.post('/listings', {
        title,
        description,
        price: Number(price) || 0,
        type,
        category,
        images
      });
      window.location.href = `/listing/${res.id}`;
    } catch (err) {
      console.error(err);
      alert('Ошибка при создании объявления');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <button 
        onClick={() => window.location.href = '/'}
        className="flex items-center text-gray-400 hover:text-black mb-8 font-bold text-xs uppercase tracking-widest transition-colors"
      >
        <ChevronLeft size={14} className="mr-1" /> На главную
      </button>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <h1 className="text-3xl font-black text-gray-900 mb-10 tracking-tighter">Новое объявление</h1>

        <form onSubmit={handleSubmit} className="space-y-10">
          {/* Images */}
          <div className="space-y-4">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">Фотографии (до 4 шт, макс 2МБ каждая)</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {images.map((img, idx) => (
                <div key={idx} className="aspect-square bg-gray-50 border border-gray-200 rounded-lg relative group overflow-hidden">
                  <img src={img} alt="Preview" className="w-full h-full object-cover" />
                  <button 
                    type="button"
                    onClick={() => removeImage(idx)}
                    className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <PlusSquare size={12} className="rotate-45" />
                  </button>
                </div>
              ))}
              {images.length < 4 && (
                <label className="aspect-square bg-gray-50 border-2 border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center text-gray-400 hover:border-primary hover:bg-blue-50 transition-all cursor-pointer p-3 group">
                  <Camera size={24} strokeWidth={1.5} className="group-hover:scale-110 transition-transform" />
                  <span className="text-[9px] font-bold mt-2 uppercase tracking-tighter text-center leading-tight">Загрузить</span>
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleFileChange}
                  />
                </label>
              )}
            </div>
          </div>

          {/* Type Selection */}
          <div className="space-y-4">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">Тип сделки</label>
            <div className="grid grid-cols-2 gap-3">
               <button 
                 type="button"
                 onClick={() => setType('sale')}
                 className={cn(
                   "p-3 rounded-lg border font-bold text-sm transition-all flex items-center justify-center gap-2",
                   type === 'sale' ? "border-primary bg-blue-50 text-primary shadow-sm" : "border-gray-200 bg-white text-gray-400 hover:bg-gray-50"
                 )}
               >
                 <DollarSign size={16} /> Продажа
               </button>
               <button 
                 type="button"
                 onClick={() => setType('exchange')}
                 className={cn(
                   "p-3 rounded-lg border font-bold text-sm transition-all flex items-center justify-center gap-2",
                   type === 'exchange' ? "border-accent bg-orange-50 text-accent shadow-sm" : "border-gray-200 bg-white text-gray-400 hover:bg-gray-50"
                 )}
               >
                 <ArrowRightLeft size={16} /> Обмен
               </button>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">Что вы предлагаете?</label>
              <input 
                type="text" 
                placeholder="Краткое название" 
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-3 bg-gray-50/50 border border-gray-200 rounded-lg focus:bg-white focus:ring-4 focus:ring-primary/5 transition-all outline-none font-medium"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">Категория</label>
                <div className="relative">
                  <select 
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full pl-4 pr-10 py-3 bg-gray-50/50 border border-gray-200 rounded-lg focus:bg-white transition-all appearance-none outline-none font-medium text-sm"
                  >
                    {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                  <Tag className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={16} />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">Цена (₽)</label>
                <div className="relative">
                  <input 
                    type="number" 
                    placeholder="0" 
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50/50 border border-gray-200 rounded-lg focus:bg-white transition-all outline-none font-bold text-lg"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">₽</span>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">Подробное описание</label>
              <textarea 
                rows={6}
                placeholder="Состояние, характеристики, причины продажи..." 
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-4 py-3 bg-gray-50/50 border border-gray-200 rounded-lg focus:bg-white focus:ring-4 focus:ring-primary/5 transition-all outline-none resize-none font-medium text-sm"
              />
            </div>
            
            <div className="flex items-center text-gray-500 bg-gray-50 border border-gray-100 p-4 rounded-lg">
               <MapPin size={16} className="mr-3 text-primary" />
               <span className="text-xs font-medium">Объявление будет закреплено за локацией <strong className="text-gray-900 font-bold">ПГТ Анна</strong></span>
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-primary hover:bg-blue-600 text-white font-black py-5 rounded-lg transition-all shadow-xl shadow-blue-50 active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100 uppercase tracking-widest text-sm"
          >
            {loading ? 'Публикация...' : 'Опубликовать'}
          </button>
        </form>
      </div>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
