import React, { useState } from 'react';
import { 
  LogIn, 
  UserPlus, 
  Mail, 
  Lock, 
  User as UserIcon,
  AlertCircle
} from 'lucide-react';
import { api, saveAuth } from '../lib/api';

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Заполните все поля');
      return;
    }
    
    if (!isLogin && !name) {
      setError('Введите ваше имя');
      return;
    }

    if (!isLogin && password.length < 6) {
      setError('Пароль должен быть не менее 6 символов');
      return;
    }

    setError('');
    setLoading(true);

    try {
      if (isLogin) {
        const { token, user } = await api.post('/auth/login', { email, password });
        saveAuth(token, user);
      } else {
        const { token, user } = await api.post('/auth/register', { email, password, displayName: name });
        saveAuth(token, user);
      }
      window.location.href = '/';
    } catch (err: any) {
      console.error('Auth Error:', err);
      // Better error messages based on text or JSON response
      const errMsg = err.error || err.message || 'Ошибка сети или неверные данные';
      if (errMsg.includes('Email already exists') || errMsg.includes('UNIQUE')) {
         setError('Пользователь с таким email уже существует');
      } else if (errMsg.includes('Invalid credentials')) {
         setError('Неверный email или пароль');
      } else {
         setError(errMsg);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4 bg-gray-50 uppercase-tracking-wide">
      <div className="w-full max-w-[420px] bg-white rounded-2xl shadow-xl shadow-blue-900/5 sm:border border-gray-200 p-8 sm:p-10 transition-all duration-300">
        
        <div className="flex bg-gray-100/80 p-1.5 rounded-xl mb-8 border border-gray-200/50">
          <button
            onClick={() => { setIsLogin(true); setError(''); }}
            className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${
              isLogin 
                ? 'bg-white text-gray-900 shadow-sm border border-gray-200/50' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Вход
          </button>
          <button
            onClick={() => { setIsLogin(false); setError(''); }}
            className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${
              !isLogin 
                ? 'bg-white text-gray-900 shadow-sm border border-gray-200/50' 
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
           Регистрация
          </button>
        </div>

        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">
            {isLogin ? 'Добро пожаловать!' : 'Создайте аккаунт'}
          </h2>
          <p className="text-sm text-gray-500 mt-2">
            {isLogin ? 'Рады видеть вас снова' : 'Присоединяйтесь к нашему сообществу'}
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-xl text-xs font-bold gap-3 flex items-start border border-red-100/50 animate-in fade-in slide-in-from-top-1">
            <AlertCircle size={16} className="mt-0.5 shrink-0" />
            <span className="leading-snug">{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">Как вас зовут?</label>
              <div className="relative group">
                <UserIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={18} />
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Иван Иванов"
                  disabled={loading}
                  className="w-full pl-11 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-4 focus:ring-primary/10 focus:border-primary/50 transition-all outline-none text-sm font-medium"
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">Email</label>
            <div className="relative group">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={18} />
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="example@mail.ru"
                disabled={loading}
                className="w-full pl-11 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-4 focus:ring-primary/10 focus:border-primary/50 transition-all outline-none text-sm font-medium"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">Пароль</label>
            <div className="relative group">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={18} />
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                disabled={loading}
                className="w-full pl-11 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-4 focus:ring-primary/10 focus:border-primary/50 transition-all outline-none text-sm font-medium"
              />
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-primary hover:bg-blue-600 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-blue-500/20 active:scale-[0.98] disabled:opacity-70 disabled:active:scale-100 flex items-center justify-center gap-2 mt-6"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
            ) : (
              isLogin ? 'Войти в аккаунт' : 'Зарегистрироваться'
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
