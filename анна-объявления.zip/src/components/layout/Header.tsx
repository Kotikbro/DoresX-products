import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Search, 
  PlusCircle, 
  User as UserIcon, 
  MessageSquare,
  LogOut,
  MapPin,
  X,
  Package
} from 'lucide-react';
import { api, clearAuth, getStoredUser } from '../../lib/api';
import { Notification } from '../../types';
import { cn } from '../../lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { ru } from 'date-fns/locale';

export default function Header() {
  const [user, setUser] = useState(getStoredUser());
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (!user) return;

    const fetchNotifications = async () => {
      try {
        const data = await api.get('/notifications');
        setNotifications(data);
        setUnreadCount(data.filter((n: any) => !n.read).length);
      } catch (e) {
        console.error(e);
      }
    };

    fetchNotifications();
    const interval = setInterval(fetchNotifications, 10000); // Polling every 10s
    return () => clearInterval(interval);
  }, [user]);

  const markAsRead = async (id: string) => {
    if (!user) return;
    try {
      await api.post('/notifications/mark-read', { id });
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogout = () => {
    clearAuth();
    setUser(null);
    window.location.reload();
  };

  return (
    <header className="bg-white border-b border-gray-200 px-6 py-2 flex items-center justify-between shrink-0 shadow-sm sticky top-0 z-50">
      <div className="flex items-center gap-8">
        <div 
          className="text-2xl font-black text-primary tracking-tighter cursor-pointer select-none"
          onClick={() => window.location.href = '/'}
        >
          АННА<span className="text-accent">.</span>ОБЪЯВЛЕНИЯ
        </div>
        <div className="hidden lg:flex items-center gap-4 text-sm font-medium">
          <span className="text-gray-400 flex items-center gap-1">
            <MapPin size={14} /> Анна, Воронежская обл.
          </span>
          <div className="h-4 w-[1px] bg-gray-200"></div>
          <a href="#" className="hover:text-primary transition-colors">Для бизнеса</a>
          <a href="#" className="hover:text-primary transition-colors">Помощь</a>
        </div>
      </div>

      <div className="flex items-center gap-4 sm:gap-6 text-sm font-semibold">
        {user ? (
          <div className="flex items-center gap-4">
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 text-gray-400 hover:text-black relative transition-colors"
              >
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-accent text-white text-[10px] flex items-center justify-center rounded-full border border-white">
                    {unreadCount}
                  </span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden animate-in fade-in zoom-in duration-150">
                  <div className="p-3 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                    <h3 className="font-bold text-xs uppercase tracking-wider text-gray-500">Уведомления</h3>
                    <button onClick={() => setShowNotifications(false)} className="text-gray-400 hover:text-gray-600">
                      <X size={16} />
                    </button>
                  </div>
                  <div className="max-h-96 overflow-y-auto scrollbar-hide">
                    {notifications.length > 0 ? (
                      notifications.map((n) => (
                        <div 
                          key={n.id} 
                          onClick={() => { markAsRead(n.id); window.location.href = n.link; }}
                          className={cn(
                            "p-3 hover:bg-gray-50 cursor-pointer transition-colors border-b border-gray-100 last:border-0",
                            !n.read && "bg-blue-50/30"
                          )}
                        >
                          <p className="text-xs font-bold text-gray-900">{n.title}</p>
                          <p className="text-xs text-gray-500 line-clamp-2 mt-0.5">{n.body}</p>
                          <p className="text-[10px] text-gray-400 mt-1">
                            {formatDistanceToNow(new Date(n.createdAt?.toDate?.() || n.createdAt), { addSuffix: true, locale: ru })}
                          </p>
                        </div>
                      ))
                    ) : (
                      <div className="p-8 text-center text-gray-400 text-xs">Нет новых уведомлений</div>
                    )}
                  </div>
                </div>
              )}
            </div>

            <button className="p-2 text-gray-400 hover:text-black hidden sm:block">
              <MessageSquare size={20} />
            </button>

            <div className="group relative">
              <button className="flex items-center gap-2 text-gray-600 hover:text-black py-2">
                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center border border-gray-200 overflow-hidden">
                  {user.photoURL ? <img src={user.photoURL} alt="" className="w-full h-full object-cover" /> : <UserIcon size={16} />}
                </div>
                <span className="hidden sm:inline">{user.displayName || 'Профиль'}</span>
              </button>
              <div className="absolute right-0 mt-0 w-48 bg-white rounded-lg shadow-xl border border-gray-200 overflow-hidden opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                <button onClick={() => window.location.href = '/profile'} className="w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 flex items-center gap-2">
                  <Package size={14} /> Мои объявления
                </button>
                <button onClick={handleLogout} className="w-full text-left px-4 py-2.5 text-sm hover:bg-red-50 text-red-500 flex items-center gap-2 border-t border-gray-100">
                  <LogOut size={14} /> Выход
                </button>
              </div>
            </div>
          </div>
        ) : (
          <button 
            onClick={() => window.location.href = '/auth'}
            className="flex items-center gap-2 text-gray-600 hover:text-black"
          >
            <UserIcon size={18} />
            Вход и регистрация
          </button>
        )}
        <button 
          onClick={() => window.location.href = '/create'}
          className="bg-primary text-white px-5 py-2.5 rounded-lg hover:bg-blue-600 shadow-sm active:scale-95 transition-all text-sm font-bold"
        >
          Подать объявление
        </button>
      </div>
    </header>
  );
}
