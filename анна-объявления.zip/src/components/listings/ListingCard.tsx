import React from 'react';
import { MapPin, Heart, ArrowRightLeft, Trash2 } from 'lucide-react';
import { Listing } from '../../types';
import { formatPrice, cn } from '../../lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { ru } from 'date-fns/locale';
import { api, getStoredUser } from '../../lib/api';

interface ListingCardProps {
  listing: Listing;
  onClick?: () => void;
  onDelete?: () => void;
}

export default function ListingCard({ listing, onClick, onDelete }: ListingCardProps) {
  const user = getStoredUser();
  const isOwner = user?.id === listing.ownerId;

  return (
    <div 
      onClick={onClick}
      className="group bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer flex flex-col"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-gray-100">
        {listing.images?.[0] ? (
          <img 
            src={listing.images[0]} 
            alt={listing.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-300 italic text-[10px] uppercase font-bold tracking-widest">
            Нет фото
          </div>
        )}
        
        <div className="absolute top-2 left-2 flex gap-1.5">
          {listing.type === 'exchange' && (
            <div className="bg-accent text-white text-[9px] font-black px-1.5 py-0.5 rounded flex items-center gap-1 shadow-sm uppercase tracking-tighter">
              <ArrowRightLeft size={10} />
              ОБМЕН
            </div>
          )}
        </div>

        <button 
          onClick={async (e) => { 
            e.stopPropagation(); 
            if (isOwner) {
              if (window.confirm('Вы уверены, что хотите удалить это объявление?')) {
                try {
                  await api.delete(`/listings/${listing.id}`);
                  if (onDelete) onDelete();
                  else window.location.reload();
                } catch (err) {
                  alert('Ошибка при удалении');
                }
              }
            } else {
              // Heart logic goes here (currently unimplemented)
            }
          }}
          className={cn(
            "absolute top-2 right-2 p-1.5 bg-white/80 backdrop-blur-sm rounded-full transition-all shadow-sm",
            isOwner ? "text-red-500 hover:bg-red-50 hover:text-red-600" : "text-gray-400 hover:text-accent"
          )}
        >
          {isOwner ? <Trash2 size={14} /> : <Heart size={14} />}
        </button>
      </div>

      <div className="p-3 flex-1 flex flex-col">
        <div className="text-lg font-bold text-gray-900 leading-tight mb-0.5">
          {listing.price === 0 ? 'Бесплатно' : `${listing.price.toLocaleString('ru-RU')} ₽`}
        </div>
        
        <h3 className="text-sm font-medium text-primary hover:underline transition-colors line-clamp-2 leading-snug">
          {listing.title}
        </h3>

        <div className="mt-auto pt-2 space-y-0.5">
          <div className="flex items-center text-gray-400 text-[10px]">
             <span className="truncate">{listing.location || 'Анна'}</span>
             <span className="mx-1">•</span>
             <span className="shrink-0">
               {formatDistanceToNow(new Date(listing.createdAt?.toDate?.() || listing.createdAt), { addSuffix: true, locale: ru })}
             </span>
          </div>
        </div>
      </div>
    </div>
  );
}
